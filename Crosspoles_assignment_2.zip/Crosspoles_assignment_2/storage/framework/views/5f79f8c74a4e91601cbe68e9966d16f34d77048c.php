

<?php $__env->startSection('content'); ?>


<div class="modal fade" id="AddUserModal" tabindex="-1" aria-labelledby="AddUserModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="AddUserModalLabel">Add User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label" for="inputFile">Name:</label>
                    <input type="text" name="name" class="name form-control" placeholder="Enter Name" id="name">
                </div>

                <div class="mb-3">
                    <label class="form-label" for="inputFile">Email:</label>
                    <input type="text" name="email" class="email form-control" placeholder="Enter Email" id="email">
                </div>

                <div class="mb-3">
                    <label class="form-label" for="inputFile">Phone:</label><br>
                    <input type="text" name="phone" id="phone" class="phone form-control" placeholder="Enter Mobile Number" id="mobile-number" pattern="\d{10}" title="Error: 10 digits are required." onkeypress="return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode &gt;= 48 && event.charCode &lt;= 57" maxlength="10" style="width:460px;"> 
                </div>

                <div class="mb-3">
                    <label for="country">Country:</label>
                    <select class="form-control country" id="country-dropdown" name="country">
                        <option value="">Select Country</option>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($country->id); ?>">
                                <?php echo e($country->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="country">State</label>
                    <select class="form-control state" id="state-dropdown" name="state">
                    </select>
                </div>

                <div class="mb-3">
                    <label for="country">City</label>
                    <select class="form-control city" id="city-dropdown" name="city">
                    </select>
                </div>
                <ul id="save_msgList"></ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary add_user">Save</button>
            </div>

        </div>
    </div>
</div>


<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <div id="success_message"></div>
            <div class="card">
                <div class="card-header">
                    <h4>
                        User List
                        <button type="button" class="btn btn-primary float-end" data-bs-toggle="modal"
                            data-bs-target="#AddUserModal">Add User</button>
                    </h4>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <td>ID</td>
                                <td>Name</td>
                                <td>Email</td>
                                <td>Phone</td>
                                <td>Country</td>
                                <td>State</td>
                                <td>City</td>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    $(document).ready(function () {

        $('#country-dropdown').on('change', function() {
            var country_id = this.value;
            $("#state-dropdown").html('');
            $.ajax({
                url:"<?php echo e(url('get-states-by-country')); ?>",
                type: "POST",
                data: {
                    country_id: country_id,
                    _token: '<?php echo e(csrf_token()); ?>' 
                },
            dataType : 'json',
            success: function(result){
                $('#state-dropdown').html('<option value="">Select State</option>'); 
                $.each(result.states,function(key,value){
                    $("#state-dropdown").append('<option value="'+value.id+'">'+value.name+'</option>');
                });
                $('#city-dropdown').html('<option value="">Select State First</option>'); 
            }
            });
        });
        $('#state-dropdown').on('change', function() {
            var state_id = this.value;
            $("#city-dropdown").html('');
            $.ajax({
                url:"<?php echo e(url('get-cities-by-state')); ?>",
                type: "POST",
                data: {
                    state_id: state_id,
                    _token: '<?php echo e(csrf_token()); ?>' 
                },
                dataType : 'json',
                success: function(result){
                    $('#city-dropdown').html('<option value="">Select City</option>'); 
                    $.each(result.cities,function(key,value){
                    $("#city-dropdown").append('<option value="'+value.id+'">'+value.name+'</option>');
                });
                }
            });
        });

        fetchusers();

        function fetchusers() {
            $.ajax({
                type: "GET",
                url: "<?php echo e(url('fetch-users')); ?>",
                dataType: "json",
                success: function (response) {
                    // console.log(response);
                    $('tbody').html("");
                    $.each(response.users, function (key, item) {
                        $('tbody').append('<tr>\
                            <td>' + item.id + '</td>\
                            <td>' + item.name + '</td>\
                            <td>' + item.email + '</td>\
                            <td>' + item.phone + '</td>\
                            <td>' + item.country + '</td>\
                            <td>' + item.state + '</td>\
                            <td>' + item.city + '</td>\
                        \</tr>');
                    });
                }
            });
        }

        $(document).on('click', '.add_user', function (e) {

            e.preventDefault();

            $(this).text('Sending..');

            var data = {
                'name': $('.name').val(),
                'email': $('.email').val(),
                'phone': $('.phone').val(),
                'country': $('.country').val(),
                'state': $('.state').val(),
                'city': $('.city').val(),
            }

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type: "POST",
                url: "<?php echo e(url('users')); ?>",
                data: data,
                dataType: "json",
                success: function (response) {
                    console.log(response);
                    if (response.status == 400) {
                        $('#save_msgList').html("");
                        $('#save_msgList').addClass('alert alert-danger');
                        $.each(response.errors, function (key, err_value) {
                            $('#save_msgList').append('<li>' + err_value + '</li>');
                        });
                        $('.add_user').text('Save');
                    } else {
                        $('#save_msgList').html("");
                        $('#success_message').addClass('alert alert-success');
                        $('#success_message').text(response.message);
                        setTimeout(function(){ $("#success_message").hide(); },1000);
                        $('#AddUserModal').find('input').val('');
                        $('.add_user').text('Save');
                        $('#AddUserModal').modal('hide');
                        fetchusers();
                    }
                }
            });

        });

        

    });
    

    var input = document.querySelector("#phone");
    intlTelInput(input, {
      initialCountry: "auto",
      geoIpLookup: function (success, failure) {
        $.get("https://ipinfo.io", function () { }, "jsonp").always(function (resp) {
          var countryCode = (resp && resp.country) ? resp.country : "us";
          success(countryCode);
        });
      },
    });


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Crosspoles_assignment_2\resources\views/users/index.blade.php ENDPATH**/ ?>