<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


use App\Http\Controllers\UsersController;

Route::get('users', [UsersController::class, 'index']);
Route::post('users', [UsersController::class, 'store']);
Route::get('fetch-users', [UsersController::class, 'fetchstudent']);



Route::post('/get-states-by-country', [UsersController::class, 'getState']);
Route::post('/get-cities-by-state', [UsersController::class, 'getCity']);