<?php 
namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;
use App\Models\{Country,State,City,NewUsers};
class Helpers {

    public static function get_country_name($c_id){
        return $c_name = Country::where('id',$c_id)->value('name');
    }
    public static function get_state_name($c_id){
        return $c_name = State::where('id',$c_id)->value('name');
    }

    public static function get_city_name($c_id){
        return $c_name = City::where('id',$c_id)->value('name');
    }
    
}
?>