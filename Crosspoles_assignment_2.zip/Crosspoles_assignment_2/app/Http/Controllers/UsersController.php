<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\{Country,State,City,NewUsers};
use Illuminate\Support\Facades\Validator;

class UsersController extends Controller
{
    public function index(){
        $data['countries'] = Country::get(["name","id"]);
        $data['users'] = NewUsers::orderBy('id','asc')->get();
        return view('users.index',$data);
    }

    public function store(Request $request){
        //dd($request->all());
        $validator = Validator::make($request->all(), [
            'name'=> 'required|max:191',
            'email'=>'required|email|max:191',
            'phone'=>'required|max:10|min:10',
            'country'=> 'required',
            'state'=> 'required',
            'city'=> 'required',
        ]);
        if($validator->fails()){
            return response()->json([
                'status'=>400,
                'errors'=>$validator->messages()
            ]);
        }else{   
            $country_name =Country::where('id',$request->input('country'))->value('name');
            $state_name =state::where('id',$request->input('state'))->value('name');
            $city_name =City::where('id',$request->input('city'))->value('name');

            $user = new NewUsers;
            $user->name = $request->input('name');
            $user->email = $request->input('email');
            $user->phone = $request->input('phone');
            $user->country = $country_name;
            $user->state = $state_name;
            $user->city = $city_name;
            $user->save();
            return response()->json([
                'status'=>200,
                'message'=>'User Added Successfully.'
            ]);
        }
    }


    public function fetchstudent(){
        $users = NewUsers::all();
        return response()->json([
            'users'=>$users,
        ]);
    }
    public function getState(Request $request){
        $data['states'] = State::where("country_id",$request->country_id)->get(["name","id"]);
        return response()->json($data);
    }
    public function getCity(Request $request){
        $data['cities'] = City::where("state_id",$request->state_id)->get(["name","id"]);
        return response()->json($data);
    }
}
